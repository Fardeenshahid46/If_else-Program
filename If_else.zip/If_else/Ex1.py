#Taking usernsame and password as input
username=input("Enter your username:")
password=input("Enter the password:")

#Checking username ans password(AND condition)
if(username=="admin" and password=="secure123"):
    print("Login successful!Welcome,Admin")
#Checking guest login(OR condition)
elif(username=="guest" or password=="guest123"):
    print("Login successful!Welcome,Guest")
#If both are incorrect
else:
    print("Invalid username or password")        